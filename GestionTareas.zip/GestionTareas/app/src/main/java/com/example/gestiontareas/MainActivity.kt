package com.example.gestiontareas

import android.content.Context
import android.media.Image
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Done
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.core.DataStore
import androidx.datastore.dataStoreFile
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.gestiontareas.ui.theme.GestionTareasTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

val Context.dataStore by preferencesDataStore(name = "preferencias")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            mostrarContenido()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalComposeUiApi::class)
@Preview
@Composable
fun mostrarContenido() {
    var tareaTexto by remember { mutableStateOf("") }
    var tareaDescripcion by remember { mutableStateOf("") }
    var tareas by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    val dataStore = LocalContext.current.dataStore
    val keyboardController = LocalSoftwareKeyboardController.current
    val (showTextFields, setShowTextFields) = remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        // Al inicializar, leer las tareas guardadas
        val tareasGuardadas = leerTexto(dataStore)
        tareas = tareasGuardadas.toMutableList()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "GESTIÓN DE TAREAS",
                        modifier = Modifier
                            .fillMaxWidth()
                            .wrapContentSize(),
                        textAlign = TextAlign.Center,
                    )
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = Color.Black,
                    titleContentColor = Color.White
                ),
            )
        },
        content = { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(Color.DarkGray)
            ) {
                if (showTextFields) {
                    TextField(
                        value = tareaTexto,
                        onValueChange = { tareaTexto = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        label = { Text("Texto de la tarea") },
                        keyboardOptions = KeyboardOptions.Default.copy(
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(onDone = {
                            keyboardController?.hide()
                        }),
                    )

                    TextField(
                        value = tareaDescripcion,
                        onValueChange = { tareaDescripcion = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Descripción de la tarea") },
                        keyboardOptions = KeyboardOptions.Default.copy(
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(onDone = {
                            keyboardController?.hide()
                        }),
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        IconButton(
                            onClick = {
                                // Agregar la nueva tarea a la lista de tareas
                                tareas = tareas + Pair(tareaTexto, tareaDescripcion)
                                // Limpiar los campos de texto
                                tareaTexto = ""
                                tareaDescripcion = ""
                                runBlocking {
                                    guardarTexto(dataStore, tareas)
                                }
                                // Ocultar los campos de texto
                                setShowTextFields(false)
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Done,
                                contentDescription = "Agregar tarea",
                                tint = Color.LightGray,
                            )
                        }
                    }
                } else {
                    LazyColumn {
                        itemsIndexed(tareas) { index, tarea ->
                            val (tareaText, tareaDescription) = tarea
                            TareaItem(
                                tarea = tareaText,
                                descripcion = tareaDescription,
                                onDeleteClick = {
                                    tareas = tareas.toMutableList().also { it.removeAt(index) }
                                    runBlocking {
                                        guardarTexto(dataStore, tareas)
                                    }
                                },
                                onHechoClick = {
                                    tareas = tareas.toMutableList().also { it.removeAt(index) }
                                    runBlocking {
                                        guardarTexto(dataStore, tareas)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            if (!showTextFields) {
                FloatingActionButton(
                    onClick = {
                        setShowTextFields(true)
                    },
                    modifier = Modifier.padding(16.dp),
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        tint = Color.Black
                    )
                }
            }
        },
        bottomBar = {
            BottomAppBar(
                containerColor = Color.Black,
                contentColor = Color.White,
                modifier = Modifier.fillMaxWidth() // Ajustar el ancho del BottomAppBar
            ) {
                Text(
                    modifier = Modifier.fillMaxWidth(), // Ajustar el ancho del Text
                    textAlign = TextAlign.Center,
                    text = "Aplicación desarrollada por Jose Mario Molina Galeas ©",
                    style = TextStyle(fontSize = 18.sp),
                    color = Color.White // Usar Color.White para que el texto sea visible en el fondo negro
                )
            }
        }
    )
}

@Composable
fun TareaItem(
    tarea: String,
    descripcion: String,
    onDeleteClick: () -> Unit,
    onHechoClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp, horizontal = 15.dp)
            .background(Color.LightGray),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = tarea, fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 10.dp))
            Text(text = descripcion, fontSize = 20.sp, color = Color.Gray,modifier=Modifier.padding(start = 15.dp))
        }
        Icon(
            imageVector = Icons.Default.Done,
            contentDescription = null,
            modifier = Modifier
                .clickable { onHechoClick() }
                .size(24.dp),
            tint = Color.Green
        )
        Icon(
            imageVector = Icons.Default.Delete,
            contentDescription = null,
            modifier = Modifier
                .clickable { onDeleteClick() }
                .size(24.dp),
            tint = Color.Red
        )
    }
}

// Función para guardar texto
suspend fun guardarTexto(dataStore: DataStore<Preferences>, tareas: List<Pair<String, String>>) {
    val clave = stringPreferencesKey("clave_tareas")
    val tareasString = tareas.joinToString(";") { "${it.first},${it.second}" }
    dataStore.edit { preferences ->
        preferences[clave] = tareasString
    }
}

suspend fun leerTexto(dataStore: DataStore<Preferences>): List<Pair<String, String>> {
    val clave = stringPreferencesKey("clave_tareas")
    val preferences = dataStore.data.first()
    val tareasString = preferences[clave] ?: ""
    return if (tareasString.isNotEmpty()) {
        tareasString.split(";").mapNotNull { it.split(",") }.map { Pair(it[0], it[1]) }
    } else {
        emptyList()
    }
}